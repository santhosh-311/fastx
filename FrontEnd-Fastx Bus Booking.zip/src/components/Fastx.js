import Header from "./Header";
import Home from "./Home";

const Fastx=()=>{
    return(
        <>
            <Header/>
            <Home/>
        </>
    )
}

export default Fastx;